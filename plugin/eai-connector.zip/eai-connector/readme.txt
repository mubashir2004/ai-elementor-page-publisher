=== EAI Connector ===
Contributors: eai
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.4.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Secure REST bridge that lets the AI - Elementor Page Publisher create and edit Elementor pages, including protected _elementor_data.

== Description ==
Companion plugin for the AI - Elementor Page Publisher prototype. Adds authenticated REST endpoints to create/update Elementor pages, save templates, sideload media, and manage page history.

== Installation ==
1. In WordPress admin go to Plugins > Add New > Upload Plugin.
2. Choose eai-connector.zip and click Install Now.
3. If WordPress says the folder already exists, click "Replace current with uploaded" (or deactivate + delete the old copy first).
4. Activate the plugin.

== Changelog ==
= 1.4.1 =
* Media sideload now handles extension-less stock image URLs (downloads first, names the file explicitly) so images reliably land in the Media Library.
= 1.4.0 =
* Template endpoints (create/list), page history, per-page CSS delivery.
